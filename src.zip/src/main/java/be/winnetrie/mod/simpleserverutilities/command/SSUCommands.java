package be.winnetrie.mod.simpleserverutilities.command;

import com.mojang.brigadier.CommandDispatcher;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public class SSUCommands {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("ssu")
                        .executes(context -> help(context.getSource()))
                        .then(Commands.literal("help")
                                .executes(context -> help(context.getSource())))
                        .then(ClaimCommands.build())
        );
    }

    private static int help(CommandSourceStack source) {
        source.sendSystemMessage(Component.literal("Simple Server Utilities commands:"));
        source.sendSystemMessage(Component.literal(" - /ssu claims help"));
        source.sendSystemMessage(Component.literal(" - /ssu claims claim"));
        source.sendSystemMessage(Component.literal(" - /ssu claims unclaim"));
        source.sendSystemMessage(Component.literal(" - /ssu claims info"));
        source.sendSystemMessage(Component.literal(" - /ssu claims flags"));
        return 1;
    }
}