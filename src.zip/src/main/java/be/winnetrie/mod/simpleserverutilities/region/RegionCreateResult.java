package be.winnetrie.mod.simpleserverutilities.region;

public enum RegionCreateResult {
    SUCCESS,
    NAME_ALREADY_EXISTS,
    OVERLAPS_PLAYER_CLAIM,
    INVALID_REGION_OVERLAP
}