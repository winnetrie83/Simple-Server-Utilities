package be.winnetrie.mod.simpleserverutilities.region;

public enum RegionRedefineResult {
    SUCCESS,
    REGION_NOT_FOUND,
    OVERLAPS_PLAYER_CLAIM,
    INVALID_REGION_OVERLAP
}